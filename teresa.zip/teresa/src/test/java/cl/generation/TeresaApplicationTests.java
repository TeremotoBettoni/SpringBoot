package cl.generation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeresaApplicationTests {

	@Test
	void contextLoads() {
	}

}
