package cl.generation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeresaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeresaApplication.class, args);
	}

}
